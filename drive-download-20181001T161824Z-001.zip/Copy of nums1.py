# nums1.py  DDG

x = 9999999999999  # int
y = 2.7878732323  # float
z = -2+2j   # complex
z2 = 6-11j   # complex
print (" integer , float, complex" )
print (x, y, z+z2)
