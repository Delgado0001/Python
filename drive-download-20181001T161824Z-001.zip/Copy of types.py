# types.py DDG
x = -100000
y = 2.71828
z = 3+1j
s = "ABCD"
#print variables
print(x,y,z)
#print types
print(type(s))
print(type(x))
print(type(y))
print(type(z))
