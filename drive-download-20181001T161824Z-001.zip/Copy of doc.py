 doc.py ddg
""" Document how
	you write your
	code.
"""
print (" Hello World ")
print (" Document your work ")
