# lin1.py

x = -3
y = -3*x+9
print(x,y)
