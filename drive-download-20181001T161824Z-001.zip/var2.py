# var2.py
a = 10 # integer (int)
b = -5  #integer (int)
s2 = 1.414 # float
s = "This is a string of characters" # string
s3 = 'How about this' # string
print (a,b,s2,s,s3)
print ("The square root of 2 is "+str(s2))
