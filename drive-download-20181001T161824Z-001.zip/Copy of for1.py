# for1.py DDG

for i in range (-10,10):
	print(i,' ',end='')
