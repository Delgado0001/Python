# casting.py DDG
a = int(-3.2)
b = float (-3)
c = str (3.141592)
d = str (bin(192))

print (a,b,c,d)
