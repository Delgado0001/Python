# while1.py DDG
i = 0
while (i < 101):
	print(i,' ',end='')
	if ( i % 10 ) == 0:
		print(" * ")
	i = i + 1
